class sum3
{
public static void main(String args[])
int a[]=new a[n];
int c;
for(int i:a)
{
c=c+i;
}
System.out.println(c);
}
