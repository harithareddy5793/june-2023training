class Main{
public static void main(String args[])
{
int[] age={12,5,34};
for(int a:age)
{
System.out.println(a);
}
}}