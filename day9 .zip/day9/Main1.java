class Main1
{
public static void main(String args[])
{int[] age={12,4,7};

for(int i=0;i<=age.length-1;i++)
{
System.out.println(age[i]);
}
}
}