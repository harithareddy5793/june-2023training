import java.util.Scanner;
class SI
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int p=nextInt();
Double t=nextDouble();
Double r=nextDouble();
Double z=(p*t*r)/100;
System.out.println(z);
}
}
